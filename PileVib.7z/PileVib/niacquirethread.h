#ifndef NIACQUIRETHREAD_H
#define NIACQUIRETHREAD_H
#include <QMutex>
#include <QThread>
#include <QWaitCondition>
#include "NIDAQmx.h"

class MainWindow;

class NIAcquireThread : public QThread
{
    Q_OBJECT

public:
    NIAcquireThread(MainWindow* parentWin=0,QObject* parent=0);

public:
    void init();
    void setParentWin(MainWindow* parentWin);
private:
    int initAcquire();
    int32 createTask();
    void clearTask();

private:
    MainWindow* m_parentWin;
    int status;
private:
    char m_taskName[32];//="pileVibAcquire";
    char m_channel[1024];
    TaskHandle  m_NIDaqTask;
    uInt32 m_numChannels;
    uInt32 m_numRead;
    uInt32 m_sampleMode;
    uInt64 m_samplesPerChannel;
    float64 m_sampleRate;
    float64 m_minVolt;
    float64 m_maxVolt;
    float64* m_pData;
};




#endif // NIACQUIRETHREAD_H
