#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QChartView>
#include <QtCharts/chartsnamespace.h>
#include <QChart>
#include <QLineSeries>
#include <QValueAxis>
#include <QTimer>
#include <QDateTime>
#include "NIDAQmx.h"
#include "niacquirethread.h"

QT_CHARTS_BEGIN_NAMESPACE
class QChart;
class QSplineSeries;
class QValueAxis;
QT_CHARTS_END_NAMESPACE

QT_CHARTS_USE_NAMESPACE


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

public:
    Ui::MainWindow* getWinUI();

private slots:
    void on_startBtn_clicked();
    void on_stopBtn_clicked();
    void waitTimeout();
    void handleTimeout();

    void on_plotBtn_clicked();

    void on_pushButton_clicked();

private:
    static const int MAXSIZE=20000;
    Ui::MainWindow *ui;
    QChart* m_chart;
    QValueAxis* m_axis;
    QTimer m_timer;
    TaskHandle  m_TaskHandle;
    uInt32 m_NumChannels;
    float64 m_Data[MAXSIZE];
    float64* m_pData;
    int m_readNum;
    long m_loop;
    long m_totalCount;
    int m_total;
    QDateTime preTime;

private:
    NIAcquireThread m_niThread;

};



#endif // MAINWINDOW_H
