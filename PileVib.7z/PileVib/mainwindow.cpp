#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtWidgets>
#include <QDebug>




MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_chart(new QChart),
    m_axis(new QValueAxis),
    m_pData(0),
    m_readNum(0),
    m_total(0)
    ,m_sysconfigdlg(new SysConfigDlg)
    ,m_niThread(this)
{
    ui->setupUi(this);
    ((QHBoxLayout*) ui->centralWidget->layout())->setStretch(0,1);
    ((QHBoxLayout*) ui->centralWidget->layout())->setStretch(1,4);
    ui->layoutLeft->setStretch(0,16);
    ui->layoutLeft->setStretch(1,3);
    ui->layoutLeft->setStretch(2,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(0,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(1,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(2,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(3,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(4,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(5,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(6,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(7,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(8,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(9,1);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(10,2);
    ((QVBoxLayout*)ui->groupBox_Phychan->layout())->setStretch(11,4);

    ui->chartview->setDragMode(QChartView::NoDrag);
    ui->chartview->setMouseTracking(true);
    ui->chartview->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->chartview->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_chart->legend()->hide();
    m_axis->setTickCount(11);
    ui->chartview->setChart(m_chart);
    ui->stopBtn->setEnabled(false);
    //ui->plotBtn->setEnabled(false);

    m_sysconfigdlg->setWindowFlag(Qt::WindowMaximizeButtonHint);
    setupMenu();
}

MainWindow::~MainWindow()
{
    if(m_pData) delete m_pData;
    delete ui;
}

void MainWindow::setupMenu()
{
    connect(ui->actionExit,&QAction::triggered,this,&MainWindow::close);
    connect(ui->actionSystmeConfigure,&QAction::triggered,m_sysconfigdlg,&SysConfigDlg::show);
}


void MainWindow::on_startBtn_clicked()
{
    float64 min,max;
    char channel[1024];
    memcpy(channel,ui->phyChannelEdit->text().toLatin1().data(),256);
    //myDAQ1/ai0:1,myDAQ2/ai0:1,myDAQ3/ai0:1,myDAQ4/ai0:1,myDAQ5/ai0:1,myDAQ6/ai0:1,myDAQ7/ai0:1,myDAQ8/ai0:1,myDAQ9/ai0:1,myDAQ10/ai0:1,myDAQ11/ai0:1,myDAQ12/ai0:1,myDAQ13/ai0:1,myDAQ14/ai0:1,myDAQ15/ai0:1,myDAQ16/ai0:1
    min=ui->minValDSBox->value();
    max=ui->maxValDSBox->value();
    if(DAQmxCreateTask("mzsacquire",&m_TaskHandle)<0) return;
    if(DAQmxCreateAIVoltageChan(m_TaskHandle,channel,"",DAQmx_Val_Cfg_Default,min,max,DAQmx_Val_Volts,NULL)<0){
        DAQmxStopTask(m_TaskHandle);
        DAQmxClearTask(m_TaskHandle);
        return;
    }
    if(DAQmxGetTaskAttribute(m_TaskHandle,DAQmx_Task_NumChans,&m_NumChannels)<0){
        DAQmxStopTask(m_TaskHandle);
        DAQmxClearTask(m_TaskHandle);
        return;
    }
    int32 sampleMode=DAQmx_Val_FiniteSamps;
    if(ui->SampleContinueRadio->isChecked())
        sampleMode=DAQmx_Val_ContSamps;
    int rate=ui->rateSBox->value();
    int samplesPerchannel=ui->samplesPerchannelSBox->value();
    if(DAQmxCfgSampClkTiming (m_TaskHandle, "OnboardClock", rate, DAQmx_Val_Rising,sampleMode,
                              samplesPerchannel)<0){
        DAQmxStopTask(m_TaskHandle);
        DAQmxClearTask(m_TaskHandle);
        return;
    }
    //DAQmxSetReadOverWrite(m_TaskHandle,DAQmx_Val_OverwriteUnreadSamps);
    //DAQmxSetReadRelativeTo(m_TaskHandle,DAQmx_Val_MostRecentSamp);
    //DAQmxSetReadOffset(m_TaskHandle,-1);
    m_readNum=0;
    m_total=0;
    m_loop=0;
    m_totalCount=0;
    if(m_pData) delete m_pData;
    m_pData=new float64[m_NumChannels*(samplesPerchannel+10)];
    m_chart->removeAllSeries();
    DAQmxStartTask(m_TaskHandle);
    preTime=QDateTime::currentDateTime();
    m_timer.setInterval(1000);
    connect(&m_timer, &QTimer::timeout, this, &MainWindow::waitTimeout);
    m_timer.start();
    ui->startBtn->setEnabled(false);
    ui->stopBtn->setEnabled(true);
    ui->rateSBox->setEnabled(false);
    ui->samplesPerchannelSBox->setEnabled(false);
}

void MainWindow::on_stopBtn_clicked()
{
    m_timer.stop();
    disconnect(&m_timer, &QTimer::timeout, this, &MainWindow::handleTimeout);
    DAQmxStopTask(m_TaskHandle);
    DAQmxClearTask(m_TaskHandle);
    ui->startBtn->setEnabled(true);
    ui->stopBtn->setEnabled(false);
    ui->rateSBox->setEnabled(true);
    ui->samplesPerchannelSBox->setEnabled(true);
}


void MainWindow::waitTimeout()
{
    int interval=ui->loopTimeDSBox->value();
    m_timer.stop();
    disconnect(&m_timer, &QTimer::timeout, this, &MainWindow::waitTimeout);
    connect(&m_timer, &QTimer::timeout, this, &MainWindow::handleTimeout);
    m_timer.setInterval(interval);
    m_timer.start();
}

void MainWindow::handleTimeout()
{
    char  errBuff[2048]={'\0'};
    int32 NumRead=0;
    int32 status=0;
    int samplesPerchannel=ui->samplesPerchannelSBox->value();
    int rate=ui->rateSBox->value();
    QDateTime curTime=QDateTime::currentDateTime();
    qint64 dt=curTime.toMSecsSinceEpoch()-preTime.toMSecsSinceEpoch();
    QString cts=curTime.toString("hh:mm:ss.zzz");
    preTime=curTime;
    status=DAQmxReadAnalogF64(m_TaskHandle,rate,10.0,DAQmx_Val_GroupByChannel,m_pData,
                              m_NumChannels*samplesPerchannel,&NumRead,NULL);
    if(NumRead<=0){// status<0){//
        DAQmxGetExtendedErrorInfo(errBuff,2048);
        qDebug()<<"Warning"<<tr("%1!!!!!!!%2").arg(errBuff).arg(NumRead);
        emit ui->stopBtn->click();
        emit ui->plotBtn->click();
        return;
    }
    m_readNum=NumRead;
    m_total+=m_readNum;
    if(m_total>MAXSIZE){
        m_loop++;
        m_total=m_readNum;
    }
    m_totalCount++;
    qDebug()<<tr("time:%1,dt:%2,count:%3,loop:%4,read number:%5,total:%6")
              .arg(cts).arg(dt)
              .arg(m_totalCount).arg(m_loop)
              .arg(NumRead).arg(m_total);
    emit ui->plotBtn->click();
}

void MainWindow::on_plotBtn_clicked()
{
    int n=m_readNum;
    if(m_total<=0) return;
    int offset=m_total-m_readNum;
    if(m_total<=m_readNum){
        m_chart->removeAllSeries();
        for(int j=0;j<m_NumChannels;j++){
            QLineSeries* line=new QLineSeries;//(QLineSeries*)m_chart->series().at(0);
            QVector<QPointF> pointList;
            for(int i=0;i<n;i++){
                pointList.append(QPointF(offset+i,m_pData[j*m_readNum+i]));
            }
            line->replace(pointList);
            m_chart->addSeries(line);
        }
        m_chart->createDefaultAxes();
        m_chart->axisY()->setMin(-6);
        m_chart->axisY()->setMax(6);
        m_chart->axisX()->setMin(0);
        m_chart->axisX()->setMax(MAXSIZE);
    }else{
        for(int j=0;j<m_NumChannels;j++){
            QLineSeries* line=(QLineSeries*)m_chart->series().at(j);
            QVector<QPointF> pointList=line->pointsVector();
            for(int i=0;i<n;i++){
                pointList.append(QPointF(offset+i,m_pData[j*m_readNum+i]));
            }
            line->replace(pointList);
        }
    }
}

void MainWindow::on_pushButton_clicked()
{
    m_niThread.setParentWin(this);
    m_niThread.init();
}

Ui::MainWindow* MainWindow::getWinUI()
{
   Ui::MainWindow* retUI=ui;
   return retUI;
}
