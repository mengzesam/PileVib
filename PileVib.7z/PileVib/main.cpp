#include <QTranslator>
#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    Q_INIT_RESOURCE(resource);
    QApplication a(argc, argv);
    QTranslator translator;
    if(translator.load(":/translations/pileVib_zh_CN.qm"))
        a.installTranslator(&translator);
    MainWindow w;
    w.setWindowIcon(QPixmap(":/images/appIcon.png"));
    w.show();

    return a.exec();
}
