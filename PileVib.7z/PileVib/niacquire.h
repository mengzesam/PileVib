#ifndef NIACQUIRE_H
#define NIACQUIRE_H
#include <QObject>
#include <QMutex>
#include <QThread>
#include <QWaitCondition>
#include "NIDAQmx.h"

class NIAcquire : public QObject
{
    Q_OBJECT
public:
    explicit NIAcquire(QObject *parent = nullptr);

signals:

public slots:

private:
    void setupAcquire();
    int32 createTask();
    void clearTask();
private:
    char m_taskName[32];//="pileVibAcquire";
    char m_channel[1024];
    TaskHandle  m_NIDaqTask;
    uInt32 m_numChannels;
    uInt32 m_numRead;
    uInt32 m_sampleMode;
    uInt64 m_samplesPerChannel;
    float64 m_sampleRate;
    float64 m_minVolt;
    float64 m_maxVolt;
    float64* m_pData;
};

#endif // NIACQUIRE_H
