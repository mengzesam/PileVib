/********************************************************************************
** Form generated from reading UI file 'mainwindowfXYczE.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef MAINWINDOWFXYCZE_H
#define MAINWINDOWFXYCZE_H

#include <QtCharts/QChartView>
#include <QtCharts/chartsnamespace.h>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionNew;
    QAction *actionOpen;
    QAction *actionSave;
    QAction *actionOptions;
    QAction *actionExit;
    QAction *actionStartTest;
    QAction *actionStopTest;
    QAction *actionStoreEnable;
    QAction *actionPrint;
    QAction *actionChannelsConfigure;
    QAction *actionDevice_Configure;
    QAction *actionKeyphasor_Configure;
    QAction *actionPicture_Shot;
    QAction *actionManual;
    QAction *actionAbout;
    QAction *actionClose;
    QAction *actionClose_All;
    QAction *actionCascade;
    QAction *actionTile;
    QAction *actionNext;
    QAction *actionPrevious;
    QAction *actionExport_to_Excel;
    QAction *actionBalancing;
    QAction *actionData_Table;
    QAction *actionTrend;
    QAction *actionBode;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *layoutLeft;
    QGroupBox *groupBox_Phychan;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLineEdit *phyChannelEdit;
    QLabel *label_2;
    QDoubleSpinBox *minValDSBox;
    QLabel *label_3;
    QDoubleSpinBox *maxValDSBox;
    QLabel *label_4;
    QSpinBox *rateSBox;
    QLabel *label_5;
    QSpinBox *samplesPerchannelSBox;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout_2;
    QRadioButton *SampleFiniteRadio;
    QRadioButton *SampleContinueRadio;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton;
    QGroupBox *groupBox_loopTime;
    QVBoxLayout *verticalLayout_2;
    QSpinBox *loopTimeDSBox;
    QHBoxLayout *horizontalLayout;
    QPushButton *startBtn;
    QPushButton *stopBtn;
    QPushButton *plotBtn;
    QtCharts::QChartView *chartview;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuEdit;
    QMenu *menuConfigure;
    QMenu *menuPlots;
    QMenu *menuTools;
    QMenu *menuWindow;
    QMenu *menuHelp;
    QMenu *menuTest;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(972, 547);
        actionNew = new QAction(MainWindow);
        actionNew->setObjectName(QString::fromUtf8("actionNew"));
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QString::fromUtf8("actionOpen"));
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QString::fromUtf8("actionSave"));
        actionOptions = new QAction(MainWindow);
        actionOptions->setObjectName(QString::fromUtf8("actionOptions"));
        actionExit = new QAction(MainWindow);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        actionStartTest = new QAction(MainWindow);
        actionStartTest->setObjectName(QString::fromUtf8("actionStartTest"));
        actionStopTest = new QAction(MainWindow);
        actionStopTest->setObjectName(QString::fromUtf8("actionStopTest"));
        actionStoreEnable = new QAction(MainWindow);
        actionStoreEnable->setObjectName(QString::fromUtf8("actionStoreEnable"));
        actionPrint = new QAction(MainWindow);
        actionPrint->setObjectName(QString::fromUtf8("actionPrint"));
        actionChannelsConfigure = new QAction(MainWindow);
        actionChannelsConfigure->setObjectName(QString::fromUtf8("actionChannelsConfigure"));
        actionDevice_Configure = new QAction(MainWindow);
        actionDevice_Configure->setObjectName(QString::fromUtf8("actionDevice_Configure"));
        actionKeyphasor_Configure = new QAction(MainWindow);
        actionKeyphasor_Configure->setObjectName(QString::fromUtf8("actionKeyphasor_Configure"));
        actionPicture_Shot = new QAction(MainWindow);
        actionPicture_Shot->setObjectName(QString::fromUtf8("actionPicture_Shot"));
        actionManual = new QAction(MainWindow);
        actionManual->setObjectName(QString::fromUtf8("actionManual"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        actionClose = new QAction(MainWindow);
        actionClose->setObjectName(QString::fromUtf8("actionClose"));
        actionClose_All = new QAction(MainWindow);
        actionClose_All->setObjectName(QString::fromUtf8("actionClose_All"));
        actionCascade = new QAction(MainWindow);
        actionCascade->setObjectName(QString::fromUtf8("actionCascade"));
        actionTile = new QAction(MainWindow);
        actionTile->setObjectName(QString::fromUtf8("actionTile"));
        actionNext = new QAction(MainWindow);
        actionNext->setObjectName(QString::fromUtf8("actionNext"));
        actionPrevious = new QAction(MainWindow);
        actionPrevious->setObjectName(QString::fromUtf8("actionPrevious"));
        actionExport_to_Excel = new QAction(MainWindow);
        actionExport_to_Excel->setObjectName(QString::fromUtf8("actionExport_to_Excel"));
        actionBalancing = new QAction(MainWindow);
        actionBalancing->setObjectName(QString::fromUtf8("actionBalancing"));
        actionData_Table = new QAction(MainWindow);
        actionData_Table->setObjectName(QString::fromUtf8("actionData_Table"));
        actionTrend = new QAction(MainWindow);
        actionTrend->setObjectName(QString::fromUtf8("actionTrend"));
        actionBode = new QAction(MainWindow);
        actionBode->setObjectName(QString::fromUtf8("actionBode"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout_3 = new QHBoxLayout(centralWidget);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        layoutLeft = new QVBoxLayout();
        layoutLeft->setSpacing(6);
        layoutLeft->setObjectName(QString::fromUtf8("layoutLeft"));
        groupBox_Phychan = new QGroupBox(centralWidget);
        groupBox_Phychan->setObjectName(QString::fromUtf8("groupBox_Phychan"));
        verticalLayout = new QVBoxLayout(groupBox_Phychan);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(groupBox_Phychan);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        phyChannelEdit = new QLineEdit(groupBox_Phychan);
        phyChannelEdit->setObjectName(QString::fromUtf8("phyChannelEdit"));

        verticalLayout->addWidget(phyChannelEdit);

        label_2 = new QLabel(groupBox_Phychan);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        minValDSBox = new QDoubleSpinBox(groupBox_Phychan);
        minValDSBox->setObjectName(QString::fromUtf8("minValDSBox"));
        minValDSBox->setMinimum(-60.000000000000000);
        minValDSBox->setMaximum(0.000000000000000);
        minValDSBox->setValue(-5.000000000000000);

        verticalLayout->addWidget(minValDSBox);

        label_3 = new QLabel(groupBox_Phychan);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        maxValDSBox = new QDoubleSpinBox(groupBox_Phychan);
        maxValDSBox->setObjectName(QString::fromUtf8("maxValDSBox"));
        maxValDSBox->setMaximum(60.000000000000000);
        maxValDSBox->setValue(5.000000000000000);

        verticalLayout->addWidget(maxValDSBox);

        label_4 = new QLabel(groupBox_Phychan);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout->addWidget(label_4);

        rateSBox = new QSpinBox(groupBox_Phychan);
        rateSBox->setObjectName(QString::fromUtf8("rateSBox"));
        rateSBox->setMinimum(1);
        rateSBox->setMaximum(10000);
        rateSBox->setValue(1000);

        verticalLayout->addWidget(rateSBox);

        label_5 = new QLabel(groupBox_Phychan);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        samplesPerchannelSBox = new QSpinBox(groupBox_Phychan);
        samplesPerchannelSBox->setObjectName(QString::fromUtf8("samplesPerchannelSBox"));
        samplesPerchannelSBox->setMinimum(1);
        samplesPerchannelSBox->setMaximum(10000);
        samplesPerchannelSBox->setValue(1000);
        samplesPerchannelSBox->setDisplayIntegerBase(10);

        verticalLayout->addWidget(samplesPerchannelSBox);

        groupBox_3 = new QGroupBox(groupBox_Phychan);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        horizontalLayout_2 = new QHBoxLayout(groupBox_3);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        SampleFiniteRadio = new QRadioButton(groupBox_3);
        SampleFiniteRadio->setObjectName(QString::fromUtf8("SampleFiniteRadio"));
        SampleFiniteRadio->setChecked(false);

        horizontalLayout_2->addWidget(SampleFiniteRadio);

        SampleContinueRadio = new QRadioButton(groupBox_3);
        SampleContinueRadio->setObjectName(QString::fromUtf8("SampleContinueRadio"));
        SampleContinueRadio->setChecked(true);

        horizontalLayout_2->addWidget(SampleContinueRadio);


        verticalLayout->addWidget(groupBox_3);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout->addItem(horizontalSpacer);

        pushButton = new QPushButton(groupBox_Phychan);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout->addWidget(pushButton);


        layoutLeft->addWidget(groupBox_Phychan);

        groupBox_loopTime = new QGroupBox(centralWidget);
        groupBox_loopTime->setObjectName(QString::fromUtf8("groupBox_loopTime"));
        verticalLayout_2 = new QVBoxLayout(groupBox_loopTime);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        loopTimeDSBox = new QSpinBox(groupBox_loopTime);
        loopTimeDSBox->setObjectName(QString::fromUtf8("loopTimeDSBox"));
        loopTimeDSBox->setMinimum(1);
        loopTimeDSBox->setMaximum(10000);
        loopTimeDSBox->setSingleStep(5);
        loopTimeDSBox->setValue(1000);

        verticalLayout_2->addWidget(loopTimeDSBox);


        layoutLeft->addWidget(groupBox_loopTime);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetNoConstraint);
        horizontalLayout->setContentsMargins(30, 0, 30, -1);
        startBtn = new QPushButton(centralWidget);
        startBtn->setObjectName(QString::fromUtf8("startBtn"));

        horizontalLayout->addWidget(startBtn);

        stopBtn = new QPushButton(centralWidget);
        stopBtn->setObjectName(QString::fromUtf8("stopBtn"));

        horizontalLayout->addWidget(stopBtn);

        plotBtn = new QPushButton(centralWidget);
        plotBtn->setObjectName(QString::fromUtf8("plotBtn"));

        horizontalLayout->addWidget(plotBtn);


        layoutLeft->addLayout(horizontalLayout);


        horizontalLayout_3->addLayout(layoutLeft);

        chartview = new QtCharts::QChartView(centralWidget);
        chartview->setObjectName(QString::fromUtf8("chartview"));

        horizontalLayout_3->addWidget(chartview);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 972, 23));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuEdit = new QMenu(menuBar);
        menuEdit->setObjectName(QString::fromUtf8("menuEdit"));
        menuConfigure = new QMenu(menuBar);
        menuConfigure->setObjectName(QString::fromUtf8("menuConfigure"));
        menuPlots = new QMenu(menuBar);
        menuPlots->setObjectName(QString::fromUtf8("menuPlots"));
        menuTools = new QMenu(menuBar);
        menuTools->setObjectName(QString::fromUtf8("menuTools"));
        menuWindow = new QMenu(menuBar);
        menuWindow->setObjectName(QString::fromUtf8("menuWindow"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        menuTest = new QMenu(menuBar);
        menuTest->setObjectName(QString::fromUtf8("menuTest"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuEdit->menuAction());
        menuBar->addAction(menuConfigure->menuAction());
        menuBar->addAction(menuTest->menuAction());
        menuBar->addAction(menuPlots->menuAction());
        menuBar->addAction(menuTools->menuAction());
        menuBar->addAction(menuWindow->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuFile->addAction(actionNew);
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionSave);
        menuFile->addSeparator();
        menuFile->addAction(actionOptions);
        menuFile->addAction(actionPrint);
        menuFile->addSeparator();
        menuFile->addAction(actionExit);
        menuEdit->addAction(actionPicture_Shot);
        menuConfigure->addAction(actionDevice_Configure);
        menuConfigure->addAction(actionKeyphasor_Configure);
        menuConfigure->addAction(actionChannelsConfigure);
        menuPlots->addAction(actionData_Table);
        menuPlots->addAction(actionTrend);
        menuPlots->addAction(actionBode);
        menuTools->addAction(actionExport_to_Excel);
        menuTools->addAction(actionBalancing);
        menuWindow->addAction(actionClose);
        menuWindow->addAction(actionClose_All);
        menuWindow->addSeparator();
        menuWindow->addAction(actionTile);
        menuWindow->addAction(actionCascade);
        menuWindow->addSeparator();
        menuWindow->addAction(actionNext);
        menuWindow->addAction(actionPrevious);
        menuHelp->addAction(actionManual);
        menuHelp->addAction(actionAbout);
        menuTest->addAction(actionStartTest);
        menuTest->addAction(actionStopTest);
        menuTest->addAction(actionStoreEnable);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        actionNew->setText(QApplication::translate("MainWindow", "New", nullptr));
        actionOpen->setText(QApplication::translate("MainWindow", "Open", nullptr));
        actionSave->setText(QApplication::translate("MainWindow", "Save", nullptr));
        actionOptions->setText(QApplication::translate("MainWindow", "Options", nullptr));
        actionExit->setText(QApplication::translate("MainWindow", "Exit", nullptr));
        actionStartTest->setText(QApplication::translate("MainWindow", "Start Test", nullptr));
        actionStopTest->setText(QApplication::translate("MainWindow", "Stop Test", nullptr));
        actionStoreEnable->setText(QApplication::translate("MainWindow", "Store Enable", nullptr));
        actionPrint->setText(QApplication::translate("MainWindow", "Print", nullptr));
        actionChannelsConfigure->setText(QApplication::translate("MainWindow", "Channels Configure", nullptr));
        actionDevice_Configure->setText(QApplication::translate("MainWindow", "Device Configure", nullptr));
        actionKeyphasor_Configure->setText(QApplication::translate("MainWindow", "Keyphasor Configure", nullptr));
        actionPicture_Shot->setText(QApplication::translate("MainWindow", "Picture Shot", nullptr));
        actionManual->setText(QApplication::translate("MainWindow", "Manual", nullptr));
        actionAbout->setText(QApplication::translate("MainWindow", "About", nullptr));
        actionClose->setText(QApplication::translate("MainWindow", "Close", nullptr));
        actionClose_All->setText(QApplication::translate("MainWindow", "Close All", nullptr));
        actionCascade->setText(QApplication::translate("MainWindow", "Cascade", nullptr));
        actionTile->setText(QApplication::translate("MainWindow", "Tile", nullptr));
        actionNext->setText(QApplication::translate("MainWindow", "Next", nullptr));
        actionPrevious->setText(QApplication::translate("MainWindow", "Previous", nullptr));
        actionExport_to_Excel->setText(QApplication::translate("MainWindow", "Export to Excel", nullptr));
        actionBalancing->setText(QApplication::translate("MainWindow", "Balancing", nullptr));
        actionData_Table->setText(QApplication::translate("MainWindow", "Data Table", nullptr));
        actionTrend->setText(QApplication::translate("MainWindow", "Trend", nullptr));
        actionBode->setText(QApplication::translate("MainWindow", "Bode", nullptr));
        groupBox_Phychan->setTitle(QApplication::translate("MainWindow", "Channel Parameters", nullptr));
        label->setText(QApplication::translate("MainWindow", "Physical channel", nullptr));
        phyChannelEdit->setText(QApplication::translate("MainWindow", "My9188Mod1/ai0:3, My9188Mod2/ai0:3, My9188Mod3/ai0:3, My9188Mod4/ai0:3, My9188Mod5/ai0:3, My9188Mod6/ai0:3, My9188Mod7/ai0:3, My9188Mod8/ai0:3", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Minimum value", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "Maximum value", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "Sample Rate", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "Samples per Channel", nullptr));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "Sample Mode ", nullptr));
        SampleFiniteRadio->setText(QApplication::translate("MainWindow", "Finite Num Sample", nullptr));
        SampleContinueRadio->setText(QApplication::translate("MainWindow", "Continue Sample", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "PushButton", nullptr));
        groupBox_loopTime->setTitle(QApplication::translate("MainWindow", "Soft Loop Time(ms)", nullptr));
        startBtn->setText(QApplication::translate("MainWindow", "Start", nullptr));
        stopBtn->setText(QApplication::translate("MainWindow", "Stop", nullptr));
        plotBtn->setText(QApplication::translate("MainWindow", "Plot", nullptr));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", nullptr));
        menuEdit->setTitle(QApplication::translate("MainWindow", "Edit", nullptr));
        menuConfigure->setTitle(QApplication::translate("MainWindow", "Configure", nullptr));
        menuPlots->setTitle(QApplication::translate("MainWindow", "Plots", nullptr));
        menuTools->setTitle(QApplication::translate("MainWindow", "Tools", nullptr));
        menuWindow->setTitle(QApplication::translate("MainWindow", "Window", nullptr));
        menuHelp->setTitle(QApplication::translate("MainWindow", "Help", nullptr));
        menuTest->setTitle(QApplication::translate("MainWindow", "Test", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // MAINWINDOWFXYCZE_H
