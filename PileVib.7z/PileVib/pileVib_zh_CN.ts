<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="28"/>
        <source>File</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="47"/>
        <source>New</source>
        <translation type="unfinished">新建</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="52"/>
        <source>Open</source>
        <translation type="unfinished">打开</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="57"/>
        <source>Save</source>
        <translation type="unfinished">保存</translation>
    </message>
</context>
</TS>
