#ifndef SYSCONFIGDLG_H
#define SYSCONFIGDLG_H

#include <QtWidgets>
#include <QDialog>


namespace Ui {
class SysConfigDlg;
}

class SysConfigDlg : public QDialog
{
    Q_OBJECT

public:
    explicit SysConfigDlg(QWidget *parent = nullptr);
    ~SysConfigDlg();

private:

private:
    Ui::SysConfigDlg *ui;

};


#endif // SYSCONFIGDLG_H
