#include "sysconfigdlg.h"
#include "ui_sysconfigdlg.h"
#include "sysconfig.h"

SysConfigDlg::SysConfigDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SysConfigDlg)
{
    ui->setupUi(this);
    ui->tabWidget->addTab(new SysConfig,tr("系统设置"));
}

SysConfigDlg::~SysConfigDlg()
{
    delete ui;
}

