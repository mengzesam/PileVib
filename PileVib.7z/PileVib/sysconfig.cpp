#include "sysconfig.h"
#include "ui_sysconfig.h"


SysConfigDelegate::SysConfigDelegate()
{

}

QWidget *SysConfigDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    EditorType editorType=evalEditorType(index);
    if(editorType==CheckBox){
        QCheckBox* editor=new QCheckBox(parent);
        //editor->setCheckState(Qt::Checked);
        return editor;
    }
    if(editorType==DoubleSpinBox){
        QDoubleSpinBox* editor=new QDoubleSpinBox(parent);
        editor->setMinimum(0.0);
        editor->setMaximum(3600.0);
        return editor;
    }
    if(editorType==ChannelsComboBox){
        QComboBox* editor=new QComboBox(parent);
        QStringList items;
        int i=0;
        for(;i<CHANNELS && i<9;i++)
            items.append(tr("Ch0%1").arg(i+1));
        for(;i<CHANNELS;i++)
            items.append(tr("Ch%1").arg(i+1));
        editor->addItems(items);
        return editor;
    }
    if(editorType==SignalComboBox){
        QComboBox* editor=new QComboBox(parent);
        QStringList items={tr("振动位移"),tr("振动速度"),tr("振动加速度"),
           tr("键相1"),tr("键相2"),tr("键相3"),tr("键相4"),tr("其他")};
        editor->addItems(items);
        return editor;
    }
    if(editorType==EUComboBox){
        QComboBox* editor=new QComboBox(parent);
        return editor;
    }
    if(editorType==CycleWiseComboBox){
        QComboBox* editor=new QComboBox(parent);
        QStringList items={tr("顺时针"),tr("逆时针")};
        editor->addItems(items);
        return editor;
    }
    if(editorType==TransformComboBox){
        QComboBox* editor=new QComboBox(parent);
        QStringList items={tr("位移"),tr("速度"),tr("加速度"),tr(" ")};
        editor->addItems(items);
        return editor;
    }
    if(editorType==OutTypeComboBox){
        QComboBox* editor=new QComboBox(parent);
        QStringList items={tr("p-p"),tr("peak"),tr("rms"),tr("mean")};
        editor->addItems(items);
        return editor;
    }
    if(editorType==ReferRotateComboBox){
        QComboBox* editor=new QComboBox(parent);
        QStringList items={tr("键相1"),tr("键相2"),tr("键相3"),tr("键相4")};
        editor->addItems(items);
        return editor;
    }
    QLineEdit* editor=new QLineEdit(parent);
    return editor;
}

void SysConfigDelegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
    QLineEdit *edit = qobject_cast<QLineEdit*>(editor);
    if (edit) {
          edit->setText(index.model()->data(index, Qt::EditRole).toString());
          return;
    }
    QDoubleSpinBox* dspinbox=qobject_cast<QDoubleSpinBox*>(editor);
    if(dspinbox){
        dspinbox->setValue(index.model()->data(index, Qt::EditRole).toDouble());
        return;
    }
    QComboBox* combobox=qobject_cast<QComboBox*>(editor);
    if(combobox){
        QString value=index.model()->data(index, Qt::EditRole).toString();
        if(combobox->count()<1)
            combobox->addItem(value);
        combobox->setCurrentText(value);
        return;
    }
    QCheckBox* checkboxEditor=qobject_cast<QCheckBox*>(editor);
    if(checkboxEditor){
        bool checked=index.model()->data(index,Qt::CheckStateRole).toBool();
        checkboxEditor->setChecked(checked);
        return;
    }
}

void SysConfigDelegate::setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
{
    QLineEdit* edit = qobject_cast<QLineEdit*>(editor);
    if(edit){
        model->setData(index, edit->text());
        return;
    }
    QDoubleSpinBox* dspinbox=qobject_cast<QDoubleSpinBox*>(editor);
    if(dspinbox){
        model->setData(index,dspinbox->value());
        return;
    }
    QComboBox* combobox=qobject_cast<QComboBox*>(editor);
    if(combobox){
        model->setData(index,combobox->currentText());
        return;
    }
    QCheckBox* checkboxEditor=qobject_cast<QCheckBox*>(editor);
    if(checkboxEditor){
        model->setData(index,checkboxEditor->checkState(),
                              Qt::CheckStateRole );

        return;
    }
}

void SysConfigDelegate::updateEditorGeometry(QWidget *editor, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    QCheckBox* checkboxEditor=qobject_cast<QCheckBox*>(editor);
    if(checkboxEditor){
        QRect rect=option.rect;
        QRect newRect=QRect(rect.x()+3,rect.y(),rect.width(), rect.height());
        editor->setGeometry(newRect);
        return;
    }
    QStyledItemDelegate::updateEditorGeometry(editor,option,index);
}

bool SysConfigDelegate::eventFilter(QObject *editor, QEvent *event)
{
    return QStyledItemDelegate::eventFilter(editor,event);
}

void SysConfigDelegate::commitAndCloseEditor()
{

}

SysConfigDelegate::EditorType SysConfigDelegate::evalEditorType(const QModelIndex &index) const
{
    //int r=index.row();
    int c=index.column();
    if(c==0 || c==2){
        return LineEdit;
    }
    if(c==3){
        return ChannelsComboBox;
    }
    if(c==1){
        return CheckBox;
    }
    if(c==4){
        return SignalComboBox;
    }
    if(c==5){
        return EUComboBox;
    }
    if(c==6 || c==7 ||c==12){
        return DoubleSpinBox;
    }
    if(c==8){
        return CycleWiseComboBox;
    }
    if(c==9){
        return TransformComboBox;
    }
    if(c==10){
        return OutTypeComboBox;
    }
    if(c==11){
        return ReferRotateComboBox;
    }
    return LineEdit;
}



//============================我是class定义分割线


SysConfig::SysConfig(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SysConfig)
{
    ui->setupUi(this);
    setupTable();
    initTableData();
    setupConnect();
}

SysConfig::~SysConfig()
{
    delete ui;
}

void SysConfig::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void SysConfig::setupConnect()
{
   connect(ui->table,&QTableWidget::cellChanged,this,&SysConfig::cellChanged);
}

void SysConfig::setupTable()
{

    ui->table->setRowCount(ROWS);
    ui->table->setColumnCount(COLUMNS);
    ui->table->verticalHeader()->hide();
    ui->table->setSizeAdjustPolicy(QTableWidget::AdjustToContents);
    QStringList heads;
    heads<<tr("ID")<<tr("选择")<<tr("标识")<<tr("通道号")<<tr("信号型式")
        <<tr("信号单位EU")<<tr("灵敏度mv/EU")<<tr("安装角度°")<<tr("转向")<<tr("积分变换")
        <<tr("输出类型")<<tr("跟踪转速")<<tr("报警值");
    for(int c=0;c<COLUMNS;c++){
        ui->table->setHorizontalHeaderItem(c,
                                           new QTableWidgetItem(heads.at(c)));
    }
    QFont headFont=ui->table->horizontalHeader()->font();
    headFont.setBold(true);
    ui->table->horizontalHeader()->setFont(headFont);
    ui->table->horizontalHeader()
            ->setStyleSheet("QHeaderView::section{background:skyblue;}");
    ui->table->setItemDelegate(new SysConfigDelegate);
    for(int r=0;r<ROWS;r++){
        for(int c=0;c<COLUMNS;c++)
            ui->table->setItem(r,c,new QTableWidgetItem(""));
    }
    for(int r=0;r<-1;r++){//ROWS;r++){
       QWidget* itemWidget=new QWidget;
       QHBoxLayout *layout = new QHBoxLayout;
       QCheckBox *box = new QCheckBox;
       layout->addWidget(box);
       layout->setMargin(0);
       layout->setAlignment(box,Qt::AlignCenter);
       itemWidget->setLayout(layout);
       ui->table->setCellWidget(r,1,itemWidget);
    }
}

void SysConfig::initTableData()
{
    QStringList angles={tr("45"),tr("135")};
    QString cyclewise=tr("顺时针");
    for(int r=0;r<ROWS;r++){
        QString value=tr("%1").arg(r+1);
        if(r<9) value=tr("0%1").arg(r+1);
        ui->table->item(r,0)->setData(Qt::EditRole,value);
        ui->table->item(r,0)
          ->setFlags((ui->table->item(r,0)->flags())
                           ^ (Qt::ItemIsEditable));
        ui->table->item(r,1)->setData(Qt::CheckStateRole,Qt::Unchecked);
        ui->table->item(r,2)->setData(Qt::EditRole,
                                                    tr("振动%1").arg(value));
        ui->table->item(r,3)->setData(Qt::EditRole,
                                                    tr("Ch%1").arg(value));
        ui->table->item(r,4)->setData(Qt::EditRole,
                                                    tr("振动位移"));
        ui->table->item(r,5)->setData(Qt::EditRole,
                                                    tr("μm"));
        ui->table->item(r,6)->setData(Qt::EditRole,
                                                    tr("7.87"));
        ui->table->item(r,7)->setData(Qt::EditRole,
                                                    angles.at(r%2));
        ui->table->item(r,8)->setData(Qt::EditRole,
                                                    cyclewise);
        ui->table->item(r,9)->setData(Qt::EditRole,
                                                    tr("位移"));
        ui->table->item(r,10)->setData(Qt::EditRole,
                                                    tr("p-p"));
        ui->table->item(r,11)->setData(Qt::EditRole,
                                                    tr("键相1"));
        ui->table->item(r,12)->setData(Qt::EditRole,
                                                    tr("125"));
    }

}

void SysConfig::cellChanged(int row,int column)
{
    if(column==4){
        QTableWidgetItem* item=ui->table->item(row,column);
        QString value=item->data(Qt::EditRole).toString();
        if(value==tr("振动位移")){
            ui->table->item(row,5)->setData(Qt::EditRole,tr("μm"));
            ui->table->item(row,6)->setData(Qt::EditRole,tr("7.87"));
            ui->table->item(row,9)->setData(Qt::EditRole,tr("位移"));
            ui->table->item(row,10)->setData(Qt::EditRole,tr("p-p"));
            ui->table->item(row,12)->setData(Qt::EditRole,tr("125"));
        }else if(value==tr("振动速度")){
            ui->table->item(row,5)->setData(Qt::EditRole,tr("mm/s"));
            ui->table->item(row,6)->setData(Qt::EditRole,tr("20"));
            ui->table->item(row,9)->setData(Qt::EditRole,tr("速度"));
            ui->table->item(row,10)->setData(Qt::EditRole,tr("rms"));
            ui->table->item(row,12)->setData(Qt::EditRole,tr("6.3"));
        }else if(value==tr("振动加速度")){
            ui->table->item(row,5)->setData(Qt::EditRole,tr("m/s^3"));
            ui->table->item(row,6)->setData(Qt::EditRole,tr("10"));
            ui->table->item(row,9)->setData(Qt::EditRole,tr("加速度"));
            ui->table->item(row,10)->setData(Qt::EditRole,tr("peak"));
            ui->table->item(row,12)->setData(Qt::EditRole,tr("10"));
        }else if(value==tr("其他")){
            ui->table->item(row,5)->setData(Qt::EditRole,tr("mV"));
            ui->table->item(row,6)->setData(Qt::EditRole,tr("1"));
            ui->table->item(row,9)->setData(Qt::EditRole,tr(" "));
            ui->table->item(row,10)->setData(Qt::EditRole,tr("peak"));
            ui->table->item(row,12)->setData(Qt::EditRole,tr("100"));
            ui->table->item(row,7)->setData(Qt::EditRole,tr("0"));
        }else{//键相
            ui->table->item(row,5)->setData(Qt::EditRole,tr("mV"));
            ui->table->item(row,6)->setData(Qt::EditRole,tr("1000"));
            ui->table->item(row,9)->setData(Qt::EditRole,tr(" "));
            ui->table->item(row,10)->setData(Qt::EditRole,tr("peak"));
            ui->table->item(row,12)->setData(Qt::EditRole,tr("3300"));
        }
    }else if(column==8 ||column==11){
        QTableWidgetItem* item=ui->table->item(row,column);
        QString value=item->data(Qt::EditRole).toString();
        for(int r=0;r<ROWS;r++){
            ui->table->item(r,column)->setData(Qt::EditRole,value);
        }
    }else if(column==9){
        QTableWidgetItem* item=ui->table->item(row,column);
        QString value=item->data(Qt::EditRole).toString();
        QString signalValue=ui->table->item(row,4)->data(Qt::EditRole).toString();
        if(signalValue==tr("振动位移") && value!=tr("位移")){
            QMessageBox::warning(this,tr("警告"),tr("必须为位移"));
            item->setData(Qt::EditRole,tr("位移"));
        }else if(signalValue==tr("振动速度")){
            if(value!=tr("位移") && value!=tr("速度")){
                QMessageBox::warning(this,tr("警告"),tr("必须为位移或速度"));
                item->setData(Qt::EditRole,tr("速度"));
            }
        }else if(signalValue==tr("振动加速度")){
            if(value!=tr("位移") && value!=tr("速度") && value!=tr("加速度")){
                QMessageBox::warning(this,tr("警告"),tr("必须为位移、速度或加速度"));
                item->setData(Qt::EditRole,tr("加速度"));
            }
        }else if(signalValue==tr("其他")){
            if(value!=tr(" ")){
                QMessageBox::warning(this,tr("警告"),tr("与信号类型不匹配"));
                item->setData(Qt::EditRole,tr(" "));
            }
        }else{//键相
            if(value!=tr(" ")){// && value!=tr(" ")){
                QMessageBox::warning(this,tr("警告"),tr("与信号类型不匹配"));
                item->setData(Qt::EditRole,tr(" "));
            }
        }
    }
}
