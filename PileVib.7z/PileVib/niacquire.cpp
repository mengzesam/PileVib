#include "niacquire.h"

NIAcquire::NIAcquire(QObject *parent) : QObject(parent)
{

}
