#include "niacquirethread.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

NIAcquireThread::NIAcquireThread(MainWindow* parentWin,QObject* parent)
    :QThread(parent)
    ,m_parentWin(0)
    ,status(-1)
    ,m_NIDaqTask(0)
    ,m_numChannels(0)
    ,m_numRead(0)
    ,m_sampleMode(DAQmx_Val_ContSamps)
    ,m_samplesPerChannel(1000)
    ,m_sampleRate(1000)
    ,m_minVolt(-5.0)
    ,m_maxVolt(5.0)
    ,m_pData(0)
{
}

void NIAcquireThread::init()
{
  if(!m_parentWin){
        status=-1;
        return;
  }
  initAcquire();
  createTask();
}

void NIAcquireThread::setParentWin(MainWindow *parentWin)
{
    if(qobject_cast<MainWindow*>(m_parentWin)) return;
    if(parentWin){
        m_parentWin=parentWin;
        status=0;
    }else
        status=-1;
}


int NIAcquireThread::initAcquire()
{
    if(!m_parentWin) return -1;
    Ui::MainWindow* ui=m_parentWin->getWinUI();
    memcpy(m_taskName,"pileVibAcquire",32);
    memcpy(m_channel,ui->phyChannelEdit->text().toLatin1().data(),1024);
    m_minVolt=ui->minValDSBox->value();
    m_maxVolt=ui->maxValDSBox->value();
    m_sampleRate=(float64)(ui->rateSBox->value());
    m_samplesPerChannel=ui->samplesPerchannelSBox->value();
    if(ui->SampleFiniteRadio->isChecked())
        m_sampleMode=DAQmx_Val_FiniteSamps;
    qDebug()<<m_channel;
}

int32 NIAcquireThread::createTask()
{
    int32 ret;
    ret=DAQmxCreateTask(m_taskName,&m_NIDaqTask);
    if(ret!=0){
        clearTask();
        return ret;
    }
    ret=DAQmxCreateAIVoltageChan(m_NIDaqTask,m_channel,"",DAQmx_Val_Cfg_Default
                                 ,m_minVolt,m_maxVolt,DAQmx_Val_Volts,NULL);
    if(ret!=0){
        clearTask();
        return ret;
    }
    ret=DAQmxGetTaskAttribute(m_NIDaqTask,DAQmx_Task_NumChans,&m_numChannels);
    if(ret!=0){
        m_numChannels=0;
        clearTask();
        return ret;
    }
    ret=DAQmxCfgSampClkTiming (m_NIDaqTask, "OnboardClock", m_sampleRate, DAQmx_Val_Rising
                               ,m_sampleMode,m_samplesPerChannel);
    if(ret!=0){
        m_numChannels=0;
        clearTask();
        return ret;
    }
    return 0;
}

void NIAcquireThread::clearTask()
{
    if(m_NIDaqTask!=0){
        DAQmxStopTask(m_NIDaqTask);
        DAQmxClearTask(m_NIDaqTask);
        m_NIDaqTask=0;
    }
}

