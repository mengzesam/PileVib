#ifndef SYSCONFIG_H
#define SYSCONFIG_H

#include <QtWidgets>

class SysConfigDelegate : public QStyledItemDelegate
{
    Q_OBJECT

public:
    enum EditorType { LineEdit,CheckBox,SpinBox,DoubleSpinBox,
                      ChannelsComboBox,SignalComboBox,
                      EUComboBox,TransformComboBox,OutTypeComboBox,
                      CycleWiseComboBox,ReferRotateComboBox
                    };
    Q_ENUM(EditorType)

    SysConfigDelegate();

    QWidget* createEditor(QWidget *parent, const QStyleOptionViewItem &option,
                          const QModelIndex &index) const override;
    void setEditorData(QWidget *editor, const QModelIndex &index) const override;
    void setModelData(QWidget *editor, QAbstractItemModel *model,
                      const QModelIndex &index) const override;
    void updateEditorGeometry(QWidget *editor, const QStyleOptionViewItem &option,
                              const QModelIndex &index) const override;

protected:
    bool eventFilter(QObject *editor, QEvent *event) override;

private slots:
    void commitAndCloseEditor();

signals:

private:
    enum EditorType evalEditorType(const QModelIndex & index) const;

private://const
    const static int CHANNELS=32;
};

//========================================================我是class 声明分隔线



namespace Ui {
class SysConfig;
}

class SysConfig : public QWidget
{
    Q_OBJECT

public:
    explicit SysConfig(QWidget *parent = nullptr);
    ~SysConfig();

protected:
    void changeEvent(QEvent *e);

private slots:
    void cellChanged(int row,int column);

private:
    void setupConnect();
    void setupTable();
    void initTableData();

private:
    Ui::SysConfig *ui;

private:
    static const int ROWS=32;
    static const int COLUMNS=13;
};




#endif // SYSCONFIG_H
