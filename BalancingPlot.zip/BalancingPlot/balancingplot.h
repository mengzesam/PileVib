#ifndef BALANCINGPLOT_H
#define BALANCINGPLOT_H

#include <QWidget>


QT_BEGIN_NAMESPACE
class QGraphicsScene;
class QGraphicsEllipseItem;
class ArrowLine;
class AngleDimension;
class QGraphicsLineItem;
class QGraphicsPathItem;
QT_END_NAMESPACE

namespace Ui {
class BalancingPlot;
}

class BalancingPlot : public QWidget
{
    Q_OBJECT

public:
    struct VibDataType{
        double vibVal;//um
        double baseAmpl;//um
        double basePhase;//°
        double lagAngle;//°
    };
    explicit BalancingPlot(QWidget *parent = 0);
    ~BalancingPlot();

protected:
    void resizeEvent(QResizeEvent *event);

private slots:

    void on_pushButton_clicked();
    void on_AXcheckBox_clicked(bool checked);
    void on_QXcheckBox_clicked(bool checked);
    void on_AYcheckBox_clicked(bool checked);
    void on_QYcheckBox_clicked(bool checked);
    void on_AVcheckBox_clicked(bool checked);
    void on_QVcheckBox_clicked(bool checked);
    void on_AXQXcheckBox_clicked(bool checked);
    void on_AYQYcheckBox_clicked(bool checked);
    void on_AVQVcheckBox_clicked(bool checked);

private:
    void setupUi();
    void setUpGraphics();
    void setupPlotTable();
    void calcWeightAngle(const VibDataType& vib);
    void plot();
    void resizeGraphics();
    void creatRotatoLine(QColor color=Qt::red);


private:
    Ui::BalancingPlot *ui;
    qreal m_originalSide;
    double m_keyProbeAngle;
    double m_XProbeAngle;
    double m_YProbeAngle;
    double m_BearingProbeAngle;
    int m_cyclewise;//-1:counterclockwise,1:clockwise
    VibDataType m_XVib;
    VibDataType m_YVib;
    VibDataType m_BearingVib;
    QGraphicsScene* m_scene;
    QGraphicsEllipseItem* m_circle;
    QGraphicsEllipseItem* m_center;
    QGraphicsPathItem* m_rotateline;
    ArrowLine* m_keyPhiLine;
    ArrowLine* m_XVibLine;
    ArrowLine* m_YVibLine;
    ArrowLine* m_BearingVibLine;
    ArrowLine* m_XWeightLine;
    ArrowLine* m_YWeightLine;
    ArrowLine* m_BearingWeightLine;
    AngleDimension* m_XWdim;
    AngleDimension* m_YWdim;
    AngleDimension* m_BWdim;

private://const
    const static int PLOTTABLE_COLS=5;
    const static int PLOTTABLE_ROWS=15;
};








#endif // BALANCINGPLOT_H
