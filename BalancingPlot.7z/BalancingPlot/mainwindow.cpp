#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtWidgets>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->statusBar->showMessage("balancing plot");
    setWindowFlags(windowFlags() & ~Qt::WindowMaximizeButtonHint);
    setFixedSize(-10+QApplication::desktop()->availableGeometry().width()
                 ,-30+QApplication::desktop()->availableGeometry().height());
}

MainWindow::~MainWindow()
{
    delete ui;
}
