#include "balancingview.h"
#include "ui_balancingview.h"
#include "balancingdelegate.h"
#include <QtWidgets>

BalancingView::BalancingView(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BalancingView)
{
    ui->setupUi(this);
    setupPlotTable();
    //setWindowFlags(windowFlags() & ~Qt::WindowMaximizeButtonHint);
    //setFixedSize(-10+QApplication::desktop()->availableGeometry().width()
                // ,-30+QApplication::desktop()->availableGeometry().height());
}

BalancingView::~BalancingView()
{
    delete ui;
}

void BalancingView::resizeEvent(QResizeEvent *event)
{
    int width=event->size().width();
    int table_width=width/3*0.92;
    ui->plotTable->setColumnWidth(0,table_width/3);
    ui->plotTable->setColumnWidth(1,table_width/6);
    ui->plotTable->setColumnWidth(2,table_width/6);
    ui->plotTable->setColumnWidth(3,table_width/6);
    ui->plotTable->setColumnWidth(4,table_width/6);
    QWidget::resizeEvent(event);

}

void BalancingView::setupPlotTable()
{
    QStringList heads;
    heads<<"名称"<<"数据来源"<<"值/基频值"<<"角度位置°"<<"滞后角°";
    ui->plotTable->setColumnCount(PLOTTABLE_COLS);
    ui->plotTable->setRowCount(PLOTTABLE_ROWS);
    ui->plotTable->setSizeAdjustPolicy(QTableWidget::AdjustToContents);
    ui->plotTable->verticalHeader()->hide();
    for(int c=0;c<PLOTTABLE_COLS;c++){
        ui->plotTable->setHorizontalHeaderItem(c,
                                           new QTableWidgetItem(heads.at(c)));
    }
    QFont headFont=ui->plotTable->horizontalHeader()->font();
    headFont.setBold(true);
    ui->plotTable->horizontalHeader()->setFont(headFont);
    ui->plotTable->horizontalHeader()->setStyleSheet("QHeaderView::section{background:skyblue;}");
    for(int r=0;r<PLOTTABLE_ROWS;r++)
        for(int c=0;c<PLOTTABLE_COLS;c++){
            ui->plotTable->setItem(r,c,new QTableWidgetItem(""));
        }
    QStringList names;
    names<<tr("转向")<<tr("键相位置")
        <<tr("X向振动")<<tr("Y向振动")<<tr("瓦振")
        <<tr("按X向加重位置")<<tr("按Y向加重位置")
        <<tr("按瓦振加重位置")<<tr("转子质量kg")<<tr("转速rpm")
        <<tr("加重半径mm")<<tr("试加重质量g")<<tr("加重1g产生激振力kgf")
        <<tr("试加重产生激振力kgf")<<tr("激振力与转子重力比%");
    QStringList values;
    values<<tr("顺时针")<<tr("/")
         <<tr("100∠45°")<<tr("100∠135°")<<tr("100∠90°");
    for(int r=0;r<names.count();r++){
        ui->plotTable->item(r,0)->setData(Qt::EditRole,names.at(r));
        ui->plotTable->item(r,1)->setData(Qt::EditRole,tr("手动输入"));
        ui->plotTable->item(r,2)->setData(Qt::EditRole,tr("0"));
        ui->plotTable->item(r,3)->setData(Qt::EditRole,tr("/"));
        ui->plotTable->item(r,4)->setData(Qt::EditRole,tr("/"));
    }
    for(int r=0;r<values.count();r++){
        ui->plotTable->item(r,2)->setData(Qt::EditRole,values.at(r));
    }
    ui->plotTable->item(1,3)->setData(Qt::EditRole,tr("90"));
    ui->plotTable->item(2,3)->setData(Qt::EditRole,tr("45"));
    ui->plotTable->item(2,4)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(3,3)->setData(Qt::EditRole,tr("135"));
    ui->plotTable->item(3,4)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(4,3)->setData(Qt::EditRole,tr("90"));
    ui->plotTable->item(4,4)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(5,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(5,2)->setData(Qt::EditRole,tr("/"));
    ui->plotTable->item(5,3)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(6,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(6,2)->setData(Qt::EditRole,tr("/"));
    ui->plotTable->item(6,3)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(7,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(7,2)->setData(Qt::EditRole,tr("/"));
    ui->plotTable->item(7,3)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(12,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(13,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(14,1)->setData(Qt::EditRole,tr("计算输出"));
    for(int r=0;r<names.count();r++){
        QTableWidgetItem* item=ui->plotTable->item(r,0);
        item->setFlags((item->flags()) ^ (Qt::ItemIsEditable));
        for(int c=2;c<5;c++){
            item=ui->plotTable->item(r,c);
            if(item->text()=="/")
                item->setFlags((item->flags()) ^ (Qt::ItemIsEditable));
        }
    }
    //ui->plotTable->item(4,4)->setFlags((item->flags()) | (Qt::ItemIsEditable));
    ui->plotTable->setItemDelegate(new BalancingDelegate());
}


void BalancingView::calcWeightAngle(const VibDataType& vib)
{
;
}

