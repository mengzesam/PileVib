#ifndef BALANCINGPLOT_H
#define BALANCINGPLOT_H

#include <QWidget>


QT_BEGIN_NAMESPACE
class QGraphicsScene;
class QGraphicsEllipseItem;
class Arrow;
class QGraphicsLineItem;
QT_END_NAMESPACE

namespace Ui {
class BalancingPlot;
}

class BalancingPlot : public QWidget
{
    Q_OBJECT

public:
    struct VibDataType{
        double vibVal;//um
        double baseAmpl;//um
        double basePhase;//°
        double lagAngle;//°
    };
    explicit BalancingPlot(QWidget *parent = 0);
    ~BalancingPlot();

protected:
    void resizeEvent(QResizeEvent *event);

private slots:

    void on_pushButton_clicked();

private:
    void setupUi();
    void setUpGraphics();
    void setupPlotTable();
    void calcWeightAngle(const VibDataType& vib);
    void plot();

    void resizeGraphics();


private:
    Ui::BalancingPlot *ui;
    QGraphicsScene* m_scene;
    QGraphicsEllipseItem* m_circle;
    QGraphicsEllipseItem* m_center;
    Arrow* m_arrow;
    QGraphicsLineItem* m_line;
    qreal m_originalSide;
    VibDataType m_XVib;
    VibDataType m_YVib;
    VibDataType m_BearingVib;
private://const
    const static int PLOTTABLE_COLS=5;
    const static int PLOTTABLE_ROWS=15;
};







#endif // BALANCINGPLOT_H
