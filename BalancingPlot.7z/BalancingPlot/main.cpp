#include "mainwindow.h"
#include "balancingview.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    //BalancingView w;
    w.show();

    return a.exec();
}
