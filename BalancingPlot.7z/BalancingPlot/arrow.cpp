/****************************************************************************

****************************************************************************/


#include "arrow.h"

#include <qmath.h>
#include <QPen>
#include <QPainter>
#include <QDebug>

Arrow::Arrow(QPointF start, QPointF end, QGraphicsItem *parent)
    :QGraphicsLineItem(parent)
    ,m_Start(start)
    ,m_End(end)
    ,m_Color(Qt::black)
{
    setFlag(QGraphicsItem::ItemIsSelectable, true);
    setPen(QPen(m_Color, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
}

QRectF Arrow::boundingRect() const
{
    qreal extra =(pen().width() + 20) / 2.0;

    return QRectF(line().p1(), QSizeF(line().p2().x() - line().p1().x(),
                                      line().p2().y() - line().p1().y()))
        .normalized()
        .adjusted(-extra, -extra, extra, extra);
    //return QGraphicsLineItem::boundingRect();
}

QPainterPath Arrow::shape() const
{
    QPainterPath path = QGraphicsLineItem::shape();
    path.addPolygon(m_arrowHead);
    return path;
}

void Arrow::updatePosition()
{
    QLineF myline(mapFromParent(m_Start),mapFromParent(m_End));
    setLine(myline);
}

void Arrow::paint(QPainter *painter, const QStyleOptionGraphicsItem *,
          QWidget *)
{
    if (int(m_Start.x())==int(m_End.x())
            && int(m_Start.y())==int(m_End.y()))
        return;


    QPen myPen = pen();
    myPen.setColor(m_Color);
    qreal arrowSize = 10;
    painter->setPen(myPen);
    painter->setBrush(m_Color);

    QTransform transf;
    //transf.translate(0,0);
    transf.rotate(rotation());
    transf.scale(scale(),scale());
    QLineF theline=transf.map(QLineF(mapFromParent(m_Start),mapFromParent(m_End)));
    setLine(theline);
    double angle = std::atan2(line().dy(), -line().dx());
    QPointF arrowP1 = line().p2() + QPointF(sin(angle + M_PI / 3) * arrowSize,
                                    cos(angle + M_PI / 3) * arrowSize);
    QPointF arrowP2 = line().p2() + QPointF(sin(angle + M_PI - M_PI / 3) * arrowSize,
                                    cos(angle + M_PI - M_PI / 3) * arrowSize);
    m_arrowHead.clear();
    m_arrowHead << line().p2() << arrowP1 << arrowP2;
    painter->drawLine(line());
    painter->drawPolygon(m_arrowHead);
    if (isSelected()) {
        painter->setPen(QPen(m_Color, 1, Qt::DashLine));
        QLineF myLine = line();
        myLine.translate(4.0*sin(angle), 4.0*cos(angle));
        painter->drawLine(myLine);
        myLine.translate(-8.0*sin(angle), -8.0*cos(angle));
        painter->drawLine(myLine);
    }
}
