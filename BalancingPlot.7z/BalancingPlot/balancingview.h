#ifndef BALANCINGVIEW_H
#define BALANCINGVIEW_H

#include <QWidget>

namespace Ui {
class BalancingView;
}

class BalancingView : public QWidget
{
    Q_OBJECT

public:
    struct VibDataType{
        double vibVal;//um
        double baseAmpl;//um
        double basePhase;//°
        double lagAngle;//°
    };
    explicit BalancingView(QWidget *parent = 0);
    ~BalancingView();

protected:
    void resizeEvent(QResizeEvent *event);


private slots:

private:
    void setupPlotTable();
    void calcWeightAngle(const VibDataType& vib);

private:
    Ui::BalancingView *ui;
    VibDataType m_XVib;
    VibDataType m_YVib;
    VibDataType m_BearingVib;
private://const
    const static int PLOTTABLE_COLS=5;
    const static int PLOTTABLE_ROWS=15;
};





#endif // BALANCINGVIEW_H
