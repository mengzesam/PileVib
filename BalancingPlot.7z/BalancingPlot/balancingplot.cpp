#include "balancingplot.h"
#include "ui_balancingplot.h"
#include "balancingdelegate.h"
#include "arrow.h"
#include <QtWidgets>
#include <QDebug>

BalancingPlot::BalancingPlot(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BalancingPlot)
    ,m_scene(0)
    ,m_circle(0)
    ,m_center(0)
{
    setupUi();
    setupPlotTable();
    setUpGraphics();
}

BalancingPlot::~BalancingPlot()
{
    delete ui;
}

void BalancingPlot::resizeEvent(QResizeEvent *event)
{
    int width=event->size().width();
    int table_width=width/3*0.92;
    ui->plotTable->setColumnWidth(0,table_width/3);
    ui->plotTable->setColumnWidth(1,table_width/6);
    ui->plotTable->setColumnWidth(2,table_width/6);
    ui->plotTable->setColumnWidth(3,table_width/6);
    ui->plotTable->setColumnWidth(4,table_width/6);
    resizeGraphics();
    QWidget::resizeEvent(event);
}

void BalancingPlot::resizeGraphics()
{
    int width=ui->graphicsView->width()*0.9;
    int height=ui->graphicsView->height()*0.9;
    m_scene->setSceneRect(-width/2.0,-height/2.0,width,height);
    qreal side=qMin(width,height);
    if(side<=1) side=100.0;
    qreal ratio=side/m_originalSide;
    if(qgraphicsitem_cast<QGraphicsEllipseItem*>(m_circle)){
        m_circle->setScale(ratio);
        m_arrow->setScale(ratio);
    }
}

void BalancingPlot::setupUi()
{
    ui->setupUi(this);
    ui->horizontalLayout_3->setStretch(0,1);
    ui->horizontalLayout_3->setStretch(1,1);
    ui->horizontalLayout_3->setStretch(2,1);
    ui->horizontalLayout_3->setStretch(3,1);
    ui->horizontalLayout_3->setStretch(4,1);
}

void BalancingPlot::setupPlotTable()
{
    QStringList heads;
    heads<<"名称"<<"数据来源"<<"值/基频值"<<"角度位置°"<<"滞后角°";
    ui->plotTable->setColumnCount(PLOTTABLE_COLS);
    ui->plotTable->setRowCount(PLOTTABLE_ROWS);
    ui->plotTable->setSizeAdjustPolicy(QTableWidget::AdjustToContents);
    ui->plotTable->verticalHeader()->hide();
    for(int c=0;c<PLOTTABLE_COLS;c++){
        ui->plotTable->setHorizontalHeaderItem(c,
                                           new QTableWidgetItem(heads.at(c)));
    }
    QFont headFont=ui->plotTable->horizontalHeader()->font();
    headFont.setBold(true);
    ui->plotTable->horizontalHeader()->setFont(headFont);
    ui->plotTable->horizontalHeader()->setStyleSheet("QHeaderView::section{background:skyblue;}");
    for(int r=0;r<PLOTTABLE_ROWS;r++)
        for(int c=0;c<PLOTTABLE_COLS;c++){
            ui->plotTable->setItem(r,c,new QTableWidgetItem(""));
        }
    QStringList names;
    names<<tr("转向")<<tr("键相位置")
        <<tr("X向振动")<<tr("Y向振动")<<tr("瓦振")
        <<tr("按X向加重位置")<<tr("按Y向加重位置")
        <<tr("按瓦振加重位置")<<tr("转子质量kg")<<tr("转速rpm")
        <<tr("加重半径mm")<<tr("试加重质量g")<<tr("加重1g产生激振力kgf")
        <<tr("试加重产生激振力kgf")<<tr("激振力与转子重力比%");
    QStringList values;
    values<<tr("顺时针")<<tr("/")
         <<tr("100∠45°")<<tr("100∠135°")<<tr("100∠90°");
    for(int r=0;r<names.count();r++){
        ui->plotTable->item(r,0)->setData(Qt::EditRole,names.at(r));
        ui->plotTable->item(r,1)->setData(Qt::EditRole,tr("手动输入"));
        ui->plotTable->item(r,2)->setData(Qt::EditRole,tr("0"));
        ui->plotTable->item(r,3)->setData(Qt::EditRole,tr("/"));
        ui->plotTable->item(r,4)->setData(Qt::EditRole,tr("/"));
    }
    for(int r=0;r<values.count();r++){
        ui->plotTable->item(r,2)->setData(Qt::EditRole,values.at(r));
    }
    ui->plotTable->item(1,3)->setData(Qt::EditRole,tr("90"));
    ui->plotTable->item(2,3)->setData(Qt::EditRole,tr("45"));
    ui->plotTable->item(2,4)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(3,3)->setData(Qt::EditRole,tr("135"));
    ui->plotTable->item(3,4)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(4,3)->setData(Qt::EditRole,tr("90"));
    ui->plotTable->item(4,4)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(5,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(5,2)->setData(Qt::EditRole,tr("/"));
    ui->plotTable->item(5,3)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(6,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(6,2)->setData(Qt::EditRole,tr("/"));
    ui->plotTable->item(6,3)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(7,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(7,2)->setData(Qt::EditRole,tr("/"));
    ui->plotTable->item(7,3)->setData(Qt::EditRole,tr("0"));
    ui->plotTable->item(12,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(13,1)->setData(Qt::EditRole,tr("计算输出"));
    ui->plotTable->item(14,1)->setData(Qt::EditRole,tr("计算输出"));
    for(int r=0;r<names.count();r++){
        QTableWidgetItem* item=ui->plotTable->item(r,0);
        item->setFlags((item->flags()) ^ (Qt::ItemIsEditable));
        for(int c=2;c<5;c++){
            item=ui->plotTable->item(r,c);
            if(item->text()=="/")
                item->setFlags((item->flags()) ^ (Qt::ItemIsEditable));
        }
    }
    //ui->plotTable->item(4,4)->setFlags((item->flags()) | (Qt::ItemIsEditable));
    ui->plotTable->setItemDelegate(new BalancingDelegate());
}

void BalancingPlot::setUpGraphics()
{
    ui->graphicsView->setRenderHint(QPainter::Antialiasing, true);
    ui->graphicsView->setDragMode(QGraphicsView::RubberBandDrag);
    ui->graphicsView->setOptimizationFlags(QGraphicsView::DontSavePainterState);
    ui->graphicsView->setViewportUpdateMode(QGraphicsView::SmartViewportUpdate);
    ui->graphicsView->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
    ui->graphicsView->setGeometry(0,0,640,360);

    m_scene=new QGraphicsScene(this);
    ui->graphicsView->setScene(m_scene);
    int width=ui->graphicsView->width()*0.9;
    int height=ui->graphicsView->height()*0.9;
    m_scene->setSceneRect(-width/2.0,-height/2.0,width,height);
    m_scene->setBackgroundBrush(QBrush(QColor(Qt::gray)));
    m_originalSide=qMin(width,height);
    qreal diameter=m_originalSide*0.75;
    m_circle=new QGraphicsEllipseItem(0,0,diameter,diameter);
    m_circle->setPos(QPointF(-diameter/2.0,-diameter/2.0));
    QPen pen(QColor(Qt::blue));
    pen.setWidth(2);
    m_circle->setPen(pen);
    m_scene->addItem(m_circle);
    m_circle->setTransformOriginPoint(diameter/2.0,diameter/2.0);
    m_center=new QGraphicsEllipseItem(0,0,6,6);
    m_center->setPos(QPointF(-3.0,-3.0));
    QBrush brush(QColor(Qt::red));
    m_center->setBrush(brush);
    m_center->setPen(QPen(Qt::NoPen));
    m_scene->addItem(m_center);
    m_arrow=new Arrow(QPointF(0,0),QPointF(sqrt(2.0)/2.0*diameter/2.0,sqrt(2.0)/2.0*diameter/2.0));
    m_arrow->setPos(0,0);
    m_arrow->setRotation(90);
    m_scene->addItem(m_arrow);
}

void BalancingPlot::calcWeightAngle(const VibDataType& vib)
{
;
}

void BalancingPlot::on_pushButton_clicked()
{
  m_arrow->setRotation(m_arrow->rotation()+15.0);


}
